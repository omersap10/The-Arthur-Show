package com.example.arthurrecycleview;

public class CharactersData {

    private String name;
    private String describe;
    private int id_;
    private int image;

    public CharactersData(String name, String describe, int id_, int image) {
        this.name = name;
        this.describe = describe;
        this.id_ = id_;
        this.image = image;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescribe()
    {
        return describe;
    }

    public void setDescribe(String describe)
    {
        this.describe = describe;
    }

    public int getId_()
    {
        return id_;
    }

    public int getImage()
    {
        return image;
    }

    public void setImage(int image)
    {
        this.image = image;
    }


}
