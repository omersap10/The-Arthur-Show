package com.example.arthurrecycleview;

public class MyData
{

    static String[] nameArray = {"Arthur Read", "Dora Read", "Buster Baxter", "Francine Frensky", "Mary Muffy Crosswire", "Alan Brain Powers", "Shelly Binky Barnes", "Frunella Deegan", "Sue Ellen Armstrong", "Nadine"};
    static String[] describeArray = {"The main character of the show, he is in the third grade and lives in Elwood City",
            "Arthur's sister, she is 4 years old",
            "Arthur's best friend. He is a white rabbit",
            "Arthur's friend, she is a monkey, Jewish and enjoys playing sports",
            "Arthur's friend, she is a monkey, daddy's girl and constantly buying expensive, trendy items",
            "Arthur's friend, he is a bear, highly academic and well-educated",
            "Arthur's friend, he is a yellow bulldog, He is in the third grade for a second time after failing",
            "Arthur's friend, she is a poodle, interested in yoga, fortune telling, and paranormal phenomena",
            "Arthur's friend, she is cat, she is interested in world culture and is skilled in martial arts",
            "Dora's imaginary friend, she is a brownish-yellow squirrel, she represents Dora's conscience and appears Dora feels guilty or scared"};

    static Integer[] drawableArray = {R.drawable.arthur, R.drawable.dora, R.drawable.buster,
            R.drawable.francine, R.drawable.muffy, R.drawable.brain, R.drawable.binky,
            R.drawable.frunella, R.drawable.sue_ellen,R.drawable.nadine};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
}
